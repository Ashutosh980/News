package com.example.tamasha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
