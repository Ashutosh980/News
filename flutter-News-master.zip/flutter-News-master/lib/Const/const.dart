final mainUrl='https://newsapi.org/v2/';
final topHeadlines='top-headlines';
final apikey='54681380611b4ba8941275d7d97b160c';